from django.contrib import admin
from django.contrib.auth.models import Group, User
from . models import *
# Register your models here.
admin.site.site_header = "ONLINE EXAMINATION SYSTEM"
admin.site.index_title = "Exam's Administration"
admin.site.index_title = "Aptech Admins"
admin.site.site_title = "ONLINE EXAM DASHBOARD"



class QuestionModelAdmin(admin.ModelAdmin):
    list_display = ["question", "exam_name", "marks"]

    class Meta:
        model = Question
        
#Decorator

class StudentAdmin(admin.ModelAdmin):
    #Fields
    fields =('<model_field_names>')
 
    #List Display
    list_display = ('<model_field_names>')
 
    #List_filter
    list_filter = ('<model_field_names>')
 
    #ordering
    ordering = ('<model_field_names>')
 
    #fieldsets
    fieldsets =(
                
                ('Optional Information',{
                    'classes' : ('collapse',),
                    'fields': ('<model_fields>')
                })
        )
admin.site.unregister(User)
admin.site.unregister(Group)
admin.site.register(Student)
admin.site.register(Exam)
admin.site.register(Question, QuestionModelAdmin)