from django.shortcuts import render, redirect, get_object_or_404
from .forms import LoginForm, RegisterForm
from django.http import HttpResponse
from .forms import EditProfileForm
from .models import Student, Question, Exam
from django.contrib import messages




